# AI Usage Record

OpenAI Codex was used to review and improve this project.

The main tasks completed with AI assistance were:

- simplifying and checking the Express server code
- fixing CSS class name mismatches and the login button layout
- making live and historical message timestamps consistent
- validating request fields before using them
- checking Node.js and SQLite package compatibility
- adding API tests, setup instructions and submission guidance

All generated changes should be reviewed and understood before submission. This file can be adjusted if the course requires a different AI disclosure format.
