var postForm = document.getElementById('postForm');
var msgArea = document.querySelector('.msgArea');
var logoutBtn = document.querySelector('.logoutBtn');
var statusDisplay = document.getElementById('statusDisplay');
var loadOlderBtn = document.getElementById('loadOlderBtn');

var token = sessionStorage.getItem('token');

var currentUsername = '';
var socket = null;
var messagesLoaded = false;
var pendingMessages = [];
var shownMessageIds = {};
var oldestMessageId = null;

postForm.addEventListener('submit', postMessage);
logoutBtn.addEventListener('click', logoutUser);
loadOlderBtn.addEventListener('click', loadOlderMessages);

init();

// 跳到登录页
function goLogin() {
    if (socket) {
        socket.disconnect();
        socket = null;
    }

    sessionStorage.removeItem('token');
    sessionStorage.removeItem('username');
    window.location.replace('/');
}

// 连socket
function connectSocket() {
    return new Promise(function (resolve) {
        socket = io({
            autoConnect: false,
            auth: {
                token: token
            }
        });

        // 收到新消息
        socket.on('message', function (message) {
            if (!messagesLoaded) {
                pendingMessages.push(message);
                return;
            }

            showMessage(message);
            msgArea.scrollTop = msgArea.scrollHeight;
        });

        // 连不上
        socket.on('connect_error', function (error) {
            var errorCode = error.data && error.data.code;

            if (errorCode == 'AUTH_REQUIRED' || errorCode == 'AUTH_INVALID') {
                goLogin();
                return;
            }
            statusDisplay.textContent = 'Unable to connect to live chat';
        });

        socket.on('auth_expired', function () {
            goLogin();
        });

        socket.on('disconnect', function (reason) {
            if (reason == 'io server disconnect') {
                goLogin();
            }
        });

        socket.once('connect', function () {
            statusDisplay.textContent = '';
            resolve();
        });

        socket.connect();
    });
}
function init() {
    if (!token) {
        goLogin();
        return;
    }

    fetch('/api/me', {
        headers: {
            Authorization: 'Bearer ' + token
        }
    }).then(function (response) {
        if (!response.ok) {
            goLogin();
            return;
        }
        return response.json();
    }).then(function (user) {
        currentUsername = user.username;
        sessionStorage.setItem('username', user.username);
        return connectSocket();
    }).then(function () {
        return loadMessages();
    }).then(function () {
        messagesLoaded = true;

        for (var i = 0; i < pendingMessages.length; i++) {
            showMessage(pendingMessages[i]);
        }

        pendingMessages = [];
        msgArea.scrollTop = msgArea.scrollHeight;
    }).catch(function () {
        goLogin();
    });
}

// update history
function loadMessages(beforeId) {
    var url = '/api/messages';
    var loadingOlder = Boolean(beforeId);
    var firstExistingMessage = loadingOlder ? msgArea.firstChild : null;
    var previousScrollHeight = loadingOlder ? msgArea.scrollHeight : 0;

    if (loadingOlder) {
        url += '?before=' + encodeURIComponent(beforeId);
    }

    return fetch(url, {
        headers: {
            Authorization: 'Bearer ' + token
        }
    }).then(function (response) {
        if (!response.ok) {
            throw new Error('Unable to load messages');
        }
        return response.json();
    }).then(function (data) {
        if (!loadingOlder) {
            msgArea.innerHTML = '';
            shownMessageIds = {};
        }

        for (var i = 0; i < data.messages.length; i++) {
            showMessage(data.messages[i], firstExistingMessage);
        }

        oldestMessageId = data.nextBeforeId;
        loadOlderBtn.hidden = !data.hasMore;
        loadOlderBtn.disabled = false;

        if (loadingOlder) {
            msgArea.scrollTop += msgArea.scrollHeight - previousScrollHeight;
        } else {
            msgArea.scrollTop = msgArea.scrollHeight;
        }
    });
}

function loadOlderMessages() {
    if (!oldestMessageId) {
        return;
    }

    loadOlderBtn.disabled = true;
    statusDisplay.textContent = '';

    loadMessages(oldestMessageId).catch(function () {
        loadOlderBtn.disabled = false;
        statusDisplay.textContent = 'Unable to load older messages';
    });
}

// logout
function logoutUser(event) {
    event.preventDefault();
    goLogin();
}

// send message
function postMessage(event) {
    event.preventDefault();

    var input = postForm.elements.message;
    var text = input.value.trim();

    if (!text) {
        return;
    }

    statusDisplay.textContent = '';

    fetch('/api/messages', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + token
        },
        body: JSON.stringify({
            text: text
        })
    }).then(function (response) {
        if (response.status == 401 || response.status == 403) {
            goLogin();
            return;
        }
        if (!response.ok) {
            return response.json().then(function (data) {
                statusDisplay.textContent = data.message;
            });
        }
        input.value = '';
        input.focus();
    }).catch(function () {
        statusDisplay.textContent = 'Unable to send message';
    });
}


function showMessage(message, beforeNode) {
    if (message.id && shownMessageIds[message.id]) {
        return;
    }

    if (message.id) {
        shownMessageIds[message.id] = true;
    }

    var name = message.username;
    if (message.username == currentUsername) {
        name = 'Me';
    }

    var box = document.createElement('div');
    box.className = 'message-card';

    var header = document.createElement('header');
    header.className = 'message-meta';

    var nameEl = document.createElement('strong');
    nameEl.textContent = name;

    var timeEl = document.createElement('time');
    var dateObj = new Date(message.createdAt);

    if (message.createdAt && !isNaN(dateObj.getTime())) {
        timeEl.textContent = dateObj.toLocaleString();
    } else if (message.time) {
        timeEl.textContent = message.time;
    } else {
        timeEl.textContent = '';
    }

    var textEl = document.createElement('p');
    textEl.textContent = message.text;

    header.appendChild(nameEl);
    header.appendChild(timeEl);
    box.appendChild(header);
    box.appendChild(textEl);

    if (beforeNode) {
        msgArea.insertBefore(box, beforeNode);
    } else {
        msgArea.appendChild(box);
    }
}
