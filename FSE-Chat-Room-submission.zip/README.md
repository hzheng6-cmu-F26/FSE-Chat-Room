# FSE Chat Room

FSE Chat Room is a small real-time chat application built with native HTML, CSS and JavaScript, Express, SQLite, JWT and Socket.IO.

## Requirements

- Node.js 20 or newer
- npm

## Setup

1. Install the dependencies:

   ```bash
   npm install
   ```

2. Copy `.env.example` to `.env`.

3. Replace the example JWT secret in `.env` with a private random value containing at least 32 characters.

4. Start the server:

   ```bash
   npm start
   ```

5. Open <http://localhost:3000>.

The SQLite database is created automatically in `server/models/chat.db`.

## Tests

Run the syntax checks and API tests with:

```bash
npm test
```

The API test uses a temporary database and does not change the local chat database.

## How it works

- Registration hashes passwords with bcrypt before saving them.
- Login returns a JWT that expires after one hour.
- Protected HTTP routes verify the JWT from the `Authorization` header.
- The browser sends new messages through `POST /api/messages`.
- Socket.IO is only used by the server to broadcast saved messages to connected users.
- Users and messages are stored in SQLite, so messages remain after refreshing or restarting.
- The `messages.user_id` field links each message to a user in the `users` table.

## API routes

- `POST /api/register`
- `POST /api/login`
- `GET /api/me`
- `GET /api/messages`
- `POST /api/messages`

## Submission

Create a clean ZIP file with:

```bash
npm run submission
```

The generated `FSE-Chat-Room-submission.zip` does not include `node_modules`, `.env`, the local database, VS Code settings or macOS metadata. Check the ZIP before uploading it.

Do not manually add `.env`, `server/models/chat.db` or `node_modules` to the submission. A marker should run `npm install` before starting the project.
